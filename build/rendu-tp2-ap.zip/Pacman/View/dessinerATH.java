package Pacman.View;

public class dessinerATH {

    // Le score, les vies ainsi que le GAME OVER ou READY

}
