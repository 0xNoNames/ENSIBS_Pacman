package Pacman.Logic;
/**
 * Classe représentant le score de la partie
 * 
 * @author François JULLION
 */

public class Score {
    
}
