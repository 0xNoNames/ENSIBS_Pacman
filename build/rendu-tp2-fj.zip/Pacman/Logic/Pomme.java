package Pacman.Logic;

/**
 * Classe représentant le fruit Pomme mangeable par Pacman
 * 
 * @author François JULLION
 */
public class Pomme extends Fruit {
    
}
