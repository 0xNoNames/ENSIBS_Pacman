package Pacman.Logic;

/**
 * Classe représentant un mur de la grille de jeu (Case Non jouable)
 * 
 * @author François JULLION
 */
public class Mur extends Case {
    
}
