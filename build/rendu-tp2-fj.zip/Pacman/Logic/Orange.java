package Pacman.Logic;

/**
 * Classe représentant le fruit Orange mangeable par Pacman
 * 
 * @author François JULLION
 */
public class Orange extends Fruit {
    
}