package Pacman.Logic;

/**
 * Classe représentant le fruit Melon mangeable par Pacman
 * 
 * @author François JULLION
 */
public class Melon extends Fruit {
    
}
