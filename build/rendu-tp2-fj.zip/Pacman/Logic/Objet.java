package Pacman.Logic;

/**
 * Classe abstraite représentant les objets que Pacman peut manger durant le jeu
 * 
 * @author François JULLION
 */
public abstract class Objet {
    
}
