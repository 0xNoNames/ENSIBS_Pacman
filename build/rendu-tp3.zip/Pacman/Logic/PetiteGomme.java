package Pacman.Logic;

/**
 * Classe représentant l'objet PetiteGomme mangeable par Pacman
 * 
 * @author François JULLION
 */
public class PetiteGomme extends Objet {
    
}
