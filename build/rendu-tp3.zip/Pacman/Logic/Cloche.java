package Pacman.Logic;

/**
 * Classe représentant le fruit Cloche mangeable par Pacman
 * 
 * @author François JULLION
 */
public class Cloche extends Fruit {
    
}
