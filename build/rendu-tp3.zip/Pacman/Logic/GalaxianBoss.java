package Pacman.Logic;

/**
 * Classe représentant le fruit GalaxianBoss mangeable par Pacman
 * 
 * @author François JULLION
 */
public class GalaxianBoss extends Fruit {
    
}
