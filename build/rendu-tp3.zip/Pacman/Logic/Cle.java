package Pacman.Logic;

/**
 * Classe représentant le fruit Clé mangeable par Pacman
 * 
 * @author François JULLION
 */
public class Cle extends Fruit {
    
}
