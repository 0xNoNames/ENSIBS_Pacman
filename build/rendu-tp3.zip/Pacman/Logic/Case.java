package Pacman.Logic;

/**
 * Classe abstraite représentant une case de la grille de jeu
 * 
 * @author François JULLION
 */
public abstract class Case {
    
}
