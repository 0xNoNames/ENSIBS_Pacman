package Pacman.Logic;

/**
 * Classe représentant l'objet GrosseGomme mangeable par Pacman
 * 
 * @author François JULLION
 */
public class GrosseGomme extends Objet {
    
}
