package Pacman.Logic;

/**
 * Classe représentant le fruit Cerise mangeable par Pacman
 * 
 * @author François JULLION
 */
public class Cerise extends Fruit {
    
}
