package Pacman.Logic;

/**
 * Classe représentant le fruit Fraise mangeable par Pacman
 * 
 * @author François JULLION
 */
public class Fraise extends Fruit {
    
}
