package Pacman.Logic;

/**
 * Classe abstraite représentant le fruit présent dans une case de la grille
 * 
 * @author François JULLION
 */
public abstract class Fruit extends Objet {
    
}
