# Commandes

`java -jar ./build/Pacman.jar`

# Jeu

Il y a possibilité de faire pause en appuyant sur la barre espace

# Fichiers ressources

Le fichier de configuration est `./Pacman/Data/config.json`. La spritesheet est `./Pacman/Data/sprites.png`.

# Sources

Le dossier `org` contient une librairie pour parser le JSON.
